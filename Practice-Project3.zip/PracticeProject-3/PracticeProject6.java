package practiceProject3;

class Nodes {
    int data;
    Node next;

    Nodes(int data) {
        this.data = data;
    }
}

class SortedCircularLinkedList {
    Node head;

    void insert(int data) {
        Node newNode = new Node(data);
        Node current = head;

        // If the list is empty, insert the new node and make it the head.
        if (current == null) {
            newNode.next = newNode;
            head = newNode;
        } else if (current.data >= data) {
            // If the new data is smaller than the head, insert it before the head.
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            // Find the correct position to insert the new data.
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    void display() {
        if (head == null) {
            System.out.println("Circular linked list is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}

public class PracticeProject6 {
    public static void main(String[] args) {
        SortedCircularLinkedList list = new SortedCircularLinkedList();

        // Insert elements in sorted order
        list.insert(3);
        list.insert(7);
        list.insert(10);
        list.insert(15);
        list.insert(20);

        System.out.println("Sorted Circular Linked List:");
        list.display();
    }
}
