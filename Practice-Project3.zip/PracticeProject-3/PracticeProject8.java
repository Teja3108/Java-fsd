package practiceProject3;

import java.util.Stack;

public class PracticeProject8 {
    public static void main(String[] args) {
      
        Stack<Integer> stack = new Stack<>();

     
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);

       
        System.out.println("Stack elements: " + stack);

 
        int poppedElement = stack.pop();
        
        System.out.println("Popped element: " + poppedElement);

        System.out.println("Updated stack elements: " + stack);
    }
}

