package practiceProject3;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    void deleteKey(int key) {
        Node current = head;
        Node prev = null;

        // If the key is found in the first node, update the head
        if (current != null && current.data == key) {
            head = current.next;
            return;
        }

        // Search for the key in the list
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        // If the key was not found
        if (current == null) {
            System.out.println("Key not found in the list.");
            return;
        }

        // Delete the key by updating the 'next' reference of the previous node
        prev.next = current.next;
    }

    void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class PracticeProject5 {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.head = new Node(1);
        list.head.next = new Node(2);
        list.head.next.next = new Node(3);
        list.head.next.next.next = new Node(4);
        list.head.next.next.next.next = new Node(5);

        System.out.println("Original Linked List:");
        list.printList();

        int keyToDelete = 3;
        list.deleteKey(keyToDelete);

        System.out.println("Linked List after deleting " + keyToDelete + ":");
        list.printList();
    }
}



