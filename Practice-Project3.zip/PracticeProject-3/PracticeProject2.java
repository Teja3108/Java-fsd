package practiceProject3;

public class PracticeProject2 {
	public static int findFourthSmallest(int[] arr, int k) {
		if (arr == null || arr.length < 4) {
			throw new IllegalArgumentException("Array should have at least 4 elements");
		}

		return quickSelect(arr, 0, arr.length - 1, k - 1);
	}

	public static int quickSelect(int[] arr, int left, int right, int k) {
		if (left == right) {
			return arr[left];
		}

		int pivotIndex = partition(arr, left, right);

		if (k == pivotIndex) {
			return arr[k];
		} else if (k < pivotIndex) {
			return quickSelect(arr, left, pivotIndex - 1, k);
		} else {
			return quickSelect(arr, pivotIndex + 1, right, k);
		}
	}

	public static int partition(int[] arr, int left, int right) {
		int pivotValue = arr[right];
		int i = left;

		for (int j = left; j < right; j++) {
			if (arr[j] < pivotValue) {
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
				i++;
			}
		}

		int temp = arr[i];
		arr[i] = arr[right];
		arr[right] = temp;

		return i;
	}

	public static void main(String[] args) {
		int[] arr = {12, 3, 1, 15, 4, 7, 11, 2};
		int fourthSmallest = findFourthSmallest(arr, 4);
		System.out.println("The fourth smallest element is: " + fourthSmallest);
	}
}





