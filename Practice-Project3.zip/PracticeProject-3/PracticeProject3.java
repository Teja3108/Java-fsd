package practiceProject3;

public class PracticeProject3 {
	public static int sumInRange(int[] arr, int L, int R) {
		if (arr == null || L < 0 || R >= arr.length || L > R) {
			throw new IllegalArgumentException("Invalid input range");
		}

		int sum = 0;
		for (int i = L; i <= R; i++) {
			sum += arr[i];
		}
		return sum;
	}

	public static void main(String[] args) {
		int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
		int L = 2; // Left index
		int R = 5; // Right index

		int result = sumInRange(arr, L, R);
		System.out.println("The sum of elements in the range [" + L + ", " + R + "] is: " + result);
	}
}


