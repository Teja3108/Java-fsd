package practiceProject9;

interface A {
	
	default void show() {
		
		System.out.println("Interface A");
	}
}


interface B extends A {
	
	default void show() {
		
		System.out.println("Interface B");
	}
}

interface C extends A {
	
	default void show() {
		
		System.out.println("Interface C");
	}
}


class D implements B, C {
	
	@Override
	public void show() {
		
		B.super.show(); 
		
		C.super.show(); 
	}
}

public class PracticeProject9 {
	
	public static void main(String[] args) {
		
		D obj = new D();
		
		obj.show();
	}
}



