package practiceProject2;

public class PracticeProject2Sleep {

	public static void main(String[] args) {

		for (int i = 1; i <= 5; i++) {
			
			try {
				
				Thread.sleep(1000);
				
				System.out.println("Thread " + i);
				
			} catch (InterruptedException e) {
				
				System.out.println("Thread interrupted.");
			}
		}
	}


}


