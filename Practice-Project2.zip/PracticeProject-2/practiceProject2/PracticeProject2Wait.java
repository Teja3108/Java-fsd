package practiceProject2;

class SharedResource {
	boolean isDataReady = false;

	synchronized void produceData() {
		
		isDataReady = true;
	}

	synchronized void consumeData() {
		
		while (!isDataReady) {
			
			try {
				
				wait(); 
				
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
	}
}

public class PracticeProject2Wait {
	
	public static void main(String[] args) {
		
		SharedResource sharedResource = new SharedResource();

		new Thread(() -> {
			
			sharedResource.produceData(); // Producer
			
		}).start();

		new Thread(() -> {
			
			sharedResource.consumeData(); // Consumer
			
		}).start();
	}
}






