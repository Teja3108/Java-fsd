package practiceProject8;

class Animal {
	private String name;
	private int age;

	
	public Animal(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void makeSound() {
		System.out.println("Bow Bow");
	}
}

class Dog extends Animal {
	
	public Dog(String name, int age) {
		super(name, age);
	}

	@Override
	public void makeSound() {
		System.out.println("The dog barks.");
	}
}

public class PracticeProject8 {
	public static void main(String[] args) {
		
		Animal genericAnimal = new Animal("Doggy", 5);
		
		Dog myDog1 = new Dog("Lucy", 1);
		Dog myDog2 = new Dog("Rocky", 3);
		

	
		System.out.println("Animal Name: " + genericAnimal.getName());
		System.out.println("Animal Age: " + genericAnimal.getAge());

		System.out.println("Dog Name: " + myDog1.getName());
		System.out.println("Dog Age: " + myDog1.getAge());
		
		System.out.println("Dog Name: " + myDog2.getName());
		System.out.println("Dog Age: " + myDog2.getAge());

		genericAnimal.makeSound();
		myDog1.makeSound();
	
	}
}



