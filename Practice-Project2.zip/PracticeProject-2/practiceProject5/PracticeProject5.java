package practiceProject5;

class moneyValidation {

	public void moneyValid(int money) throws MoneyNotFoundException {

		int balance = 100000;

		if (money <= balance) {
			System.out.println("Balance is: " + (balance - money));
		} else {
			throw new MoneyNotFoundException(moneyContraints.NO_MONEY);
		}
	}
}

class moneyContraints {
	public static final String NO_MONEY = "Your balance is low to meet the transaction";
}

class MoneyNotFoundException extends Exception {

	public MoneyNotFoundException(String noMoney) {
		super(noMoney);
	}
}

public class PracticeProject5 {
	public static void main(String[] args) {
		moneyValidation money = new moneyValidation();

		try {
			money.moneyValid(200000);
		} catch (MoneyNotFoundException e) {
			System.out.println("Caught MoneyNotFoundException: " + e.getMessage());
		} finally {
			System.out.println("Code Executed");
		}
	}
}
