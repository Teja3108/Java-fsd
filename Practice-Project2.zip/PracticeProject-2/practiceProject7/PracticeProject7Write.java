package practiceProject7;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

public class PracticeProject7Write {
	
	 public static void main(String[] args) throws IOException {
	        
	        Path myPath = Paths.get("C:/Users/tejag/Documents/Test");
	        
	        List<String> lines = new ArrayList<>();
	        lines.add("America");
	        lines.add("Brazil");
	        lines.add("China");
	        lines.add("Ethiopia");
	        lines.add("France");
	        
	        Files.write(myPath, lines, 
	                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
	        
	        System.out.println("Data written and appended to the file");
	    }

}
