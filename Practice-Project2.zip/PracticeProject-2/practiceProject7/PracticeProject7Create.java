package practiceProject7;

import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class PracticeProject7Create {
	
	public static void main(String[] args) throws IOException {

        Path path = Paths.get("C:/Users/tejag/Documents/Test");

        try {
            Files.createFile(path);
            
            System.out.println("File created successfully..");
            
        } catch (FileAlreadyExistsException ex) {
            
            System.err.println("File already exists");
        }
    }
	
	

}
