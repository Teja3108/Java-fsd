package practiceProject1;

public class PracticeProject1Extends implements Runnable{
	
	 public void run() {
		 
	        for (int i = 1; i <= 5; i++) {
	        	
	            System.out.println("Thread: " + i);
	        }
	    }

	public static void main(String[] args) {
			
		
		PracticeProject1Extends thread = new PracticeProject1Extends();
		
	        Thread thread1 = new Thread(thread);
	        
	        Thread thread2 = new Thread();

	        thread1.start();

	        thread2.start();
	}

}