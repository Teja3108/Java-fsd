package practiceProject1;

public class PracticeProject1Implements extends Thread{

	public void run() {

		System.out.println("Thread is active");
	}

	public static void main(String[] args) {

		PracticeProject1Implements th = new PracticeProject1Implements();

		th.start();



	}
}
