package practiceProjectAP;

public class PracticeProject4 {
	
	private int id;
	
	private String name;
	
	private String department;
	
				// Default Constructor
	
	PracticeProject4(){
		
		int id = 100;
		
		String name = "Teja";
		
		String department = "Testing";
		
		System.out.println("Employee id: " + id + "Employee name: " + name
				+ "Department: " + department);
	}
	
			//parameterize Constructor
	
	PracticeProject4(int id, String name, String department){
		
		this.id = id;
		
		this.name = name;
		
		this.department = department;
		
		
	}
	
	public String toString() {
		
		return "Employee id: " + this.id + "Employee name: " + this.name
				+ "Department: " + this.department;
	}

	public static void main(String[] args) {

		PracticeProject4 Q4 = new PracticeProject4(101, "Teja", "Developer");
		
		PracticeProject4 Q4default = new PracticeProject4();
		
		String list =  Q4.toString();
		
		System.out.println(list);
	}

}
