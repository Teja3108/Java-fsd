package practiceProjectAP;

public class PracticeProject8 {
	
	public static void main(String[] args) {
		
		String str = "I love Java"; // immutable
		
		//StringBuffer (mutable)
		
		StringBuffer string1 = new StringBuffer(str);
		
		string1.append(" and Python");
		
		System.out.println(string1);
		
		//StringBuilder (mutable)
		
		StringBuilder string2 = new StringBuilder(str);
		
		string2.append(" and c#");
		
		System.out.println(string2);

		
	}

}
