package practiceProjectAP;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

public class PracticeProject5 {

	public static void main(String[] args) {

		//Array List

		ArrayList <String> arr = new ArrayList<String>();

		arr.add("One Piece");
		arr.add("Naruto");
		arr.add("Bleach");
		arr.add("Dragon ball");

		for(String animes : arr) {

			System.out.println(animes);
		}

		//Linked List

		LinkedList <String> link = new LinkedList <String>();

		link.add("One Piece");
		link.add("Naruto");
		link.add("Bleach");
		link.add("Dragon Ball");

		for(String animes : link) {

			System.out.println(animes);
		}

		//HashSet

		Set<String> hash = new HashSet<String>();

		hash.add("BMW");
		hash.add("Ferrari");
		hash.add("Mercedece");
		hash.add("lamborghini");

		for(String cars : hash) {

			System.out.println(cars);
		}
		
		//HashMap
		
		Map<Integer,String> map = new HashMap<Integer,String>();
		
		map.put(1, "India");
		map.put(2, "USA");
		map.put(3, "Canada");
		map.put(4, "Russia");
		
		 for (Map.Entry<Integer, String> countries : map.entrySet()) {
	            System.out.println(countries.getKey() + " : " + countries.getValue());
	        }
	}

}
