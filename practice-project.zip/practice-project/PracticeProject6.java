package practiceProjectAP;

import java.util.HashMap;
import java.util.Map;

public class PracticeProject6 {

	//Maps

	public static void main(String[] args) {

		Map<Integer,String> map = new HashMap<Integer,String>();

		map.put(1, "India");
		map.put(2, "USA");
		map.put(3, "Canada");
		map.put(4, "Russia");

		for (Map.Entry<Integer, String> countries : map.entrySet()) {
			System.out.println(countries.getKey() + " : " + countries.getValue());
		}

	}

}
