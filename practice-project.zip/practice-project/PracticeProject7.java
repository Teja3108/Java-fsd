package practiceProjectAP;

public class PracticeProject7 {

	//Inner classes

	private int outerNum = 10;

	public class InnerClass {

		private int innerNum = 20;

		public void display() {
			System.out.println("outerValue = " + outerNum + 
					", innerValue = " + innerNum);
		}
	}


	public static void main(String[] args) {

		PracticeProject7 q7 = new PracticeProject7();

		InnerClass inner = q7.new InnerClass();

		inner.display();




	}

}
