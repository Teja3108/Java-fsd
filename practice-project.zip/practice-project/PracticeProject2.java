package practiceProject2;

class AccessModifiers {
	
	//Access Modifiers

	public void publicMethod() {

		System.out.println("public Method");
	}

	private void privateMethod() {

		System.out.println("private Method");
	}

	protected void protectedMethod() {

		System.out.println("protected Method");
	}

	void defaultMethod() {

		System.out.println("default Method");


	}

}
public class PracticeProject2 {
	
	public static void main(String[] args) {

		AccessModifiers q2 = new AccessModifiers();
		
		q2.publicMethod(); // Able to access

	//	q2.privateMethod(); // Unable to access (limited to class)
		
		q2.protectedMethod(); // Able to access
		
		q2.defaultMethod(); // Able to access


	}

}
