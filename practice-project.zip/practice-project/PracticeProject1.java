package practiceProject1;

public class PracticeProject1 {

	public static void main(String[] args) {
		
		//Implicit casting (Widening) 

		int intValue = 20;
		
		long longIntValue = intValue;
		
		System.out.println("Implicit casting: " + longIntValue);
		
		
		//Explicit casting (Narrowing)
		
		long longIntValue1 = 20;
		
		int intValue1 = (int) longIntValue1;
		
		System.out.println("Explicit casting: " + intValue1);
		
	}

}
