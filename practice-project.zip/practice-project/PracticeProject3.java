package practiceProjectAP;

public class PracticeProject3 {
	
	//Calling a methods
	
	public int add(int a, int b) {
		
		return a + b;
	}

	public int sub(int a, int b) {
		
		return a - b;
	}
	
	public static void main(String[] args) {
		
		PracticeProject3 q3 = new PracticeProject3();
		
		 int add =  q3.add(150, 150);
		 
		 System.out.println("Addition of 2 numbers is: " + add);
		 
		 int sub = q3.sub(200, 100);
		 
		 System.out.println("Subtraction of 2 numbers is: " + sub);

		
		
		
	}

}
