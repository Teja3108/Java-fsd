package practiceProject4;

public class ExponentialSearch {
	public static int exponentialSearch(int[] arr, int target) {
		if (arr[0] == target) {
			return 0; 
		}

		int bound = 1;
		while (bound < arr.length && arr[bound] <= target) {
			bound *= 2;
		}

		return binarySearch(arr, target, bound / 2, Math.min(bound, arr.length - 1));
	}

	public static int binarySearch(int[] arr, int target, int left, int right) {
		if (left <= right) {
			int mid = left + (right - left) / 2;
			if (arr[mid] == target) {
				return mid; // Target found at index `mid`.
			} else if (arr[mid] < target) {
				return binarySearch(arr, target, mid + 1, right);
			} else {
				return binarySearch(arr, target, left, mid - 1);
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		int[] arr = {2, 4, 7, 10, 15, 19, 22, 24, 31, 35};
		int target = 15;
		int result = exponentialSearch(arr, target);
		if (result != -1) {
			System.out.println("Target " + target + " found at index " + result);
		} else {
			System.out.println("Target " + target + " not found in the array");
		}
	}
}

