package practiceProject4;


import java.util.Arrays;
import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {

		int a[] = new int[] {2,4,1,5,3,10,9};
		
		Arrays.sort(a);
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the value to search: ");
		
		int key = sc.nextInt();
		
		int flag = 0;
		
		int i = 0;
		
		for(i = 0; i<a.length; i++) {
			
			if(a[i] == key) {
				
				flag = 1;
				break;
			}
			
			else {
				
				flag = 2;
			}
			
		}
		
		if(flag == 1) {
			
			System.out.println("Key found at: " + i);
		}
		
		else {
			
			System.out.println("key not found");
		}
		
	}

}
