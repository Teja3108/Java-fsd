package practiceProject4;


import java.util.Arrays;
import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {

		int a[] = new int[] {5,1,3,7,2,8,10};

		Arrays.sort(a);

		Scanner sc = new Scanner(System.in);

		System.out.println("Sorted array: ");

		for(int i : a) {

			System.out.print(i+ "  ");
		}
		System.out.println();

		System.out.println("Enter the key value: ");

		int key = sc.nextInt();

		int flag = 0;

		int i = 0;

		int high = a.length-1;

		int low = 0;

		int mid = 0;
		while(low<=high) {
			mid=(low+high)/2;
			if(a[mid]==key) {
				flag=1;
				break;
			}
			else if(a[mid]<key){
				low=mid+1;
			}
			else {
				high=mid-1;
			}
		}

		if(flag==1) {
			System.out.println("element is found at index "+mid);
		}
		else {
			System.out.println("element is not found ");
		}



	}

}
